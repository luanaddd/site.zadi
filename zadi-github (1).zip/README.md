# ZADI

Site estático da ZADI.

## Estrutura
- `index.html` — página principal
- `styles.css` — estilos
- `script.js` — interações e galerias
- `images/` — imagens dos produtos

## Publicação
O projeto é estático e os arquivos da raiz podem ser publicados diretamente por um serviço de hospedagem de sites estáticos.
